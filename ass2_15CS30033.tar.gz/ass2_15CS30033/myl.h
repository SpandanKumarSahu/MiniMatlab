#ifndef _MYL_H
#define _MYL_H
#define ERR 1
#define OK 0
int printStr(char *);
int printInt(int);
int readInt(int *);
int readFlt(float *);
int printFlt(float);
#endif
