#include "myl.h"
#include <stdio.h>

int main(){
  printStr("Hello\n");
  int x = -52;
  printInt(x);
  return 0;
}
